import React, { Fragment, useState } from "react";
import { useNavigate } from "react-router-dom";
import * as Icons from "../../icons";

const { FolderOpen, MoreVertical, Plus, Trash2 } = Icons;
import { Menu, Transition } from "@headlessui/react";
import AddSubTask from "./AddSubTask";
import ConfirmatioDialog from "../Dialogs";
import UpdateTask from "./UpdateTask";
import { deleteTask } from "../../redux/slices/taskSlice";
import { useDispatch } from "react-redux";

const TaskDialog = ({ task }) => {
  const [open, setOpen] = useState(false);
  const [openEdit, setOpenEdit] = useState(false);
  const [openDialog, setOpenDialog] = useState(false);
  const [selected, setSelected] = useState(null);

  const navigate = useNavigate();
  const dispatch = useDispatch();

  const deleteHandler = () => {
    if (selected !== null) {
      dispatch(deleteTask({ id: selected }));
      setSelected(null);
      setOpenDialog(false);
    }
  };

  const deleteClick = (id) => {
    setSelected(id);
    setOpenDialog(true);
  };

  const handleOpenTask = () => {
    // Use task_id if _id is not available
    const taskId = task?._id || task?.task_id;
    if (taskId) {
      navigate(`/task/${taskId}`);
    } else {}
  };

  const items = [
    {
      label: "Open Task",
      icon: <FolderOpen className='tm-icon mr-2' aria-hidden='true' />,
      onClick: handleOpenTask
    },
    {
      label: "Edit",
      icon: <Plus className='tm-icon mr-2' aria-hidden='true' />,
      onClick: () => {
        if (task?.task_id) {
          setOpenEdit(true);
        } else {}
      }
    },
  ];

  return (
    <>
      <div>
        <Menu as='div' className='relative inline-block text-left'>
          <Menu.Button className='inline-flex w-full justify-center rounded-md px-4 py-2 text-sm font-medium text-gray-600'>
            <MoreVertical className='tm-icon' />
          </Menu.Button>

          <Transition
            as={Fragment}
            enter='transition ease-out duration-100'
            enterFrom='transform opacity-0 scale-95'
            enterTo='transform opacity-100 scale-100'
            leave='transition ease-in duration-75'
            leaveFrom='transform opacity-100 scale-100'
            leaveTo='transform opacity-0 scale-95'
          >
            <Menu.Items className='absolute right-0 z-50 mt-2 w-56 origin-top-right divide-y divide-gray-100 rounded-md bg-white shadow-lg ring-1 ring-black/5 focus:outline-none'>
              <div className='px-1 py-1 space-y-2'>
                {items.map((el) => (
                  <Menu.Item key={el.label}>
                    {({ active }) => (
                      <button
                        onClick={el.onClick}
                        className={`${
                          active ? "bg-blue-500 text-white" : "text-gray-900"
                        } group flex w-full items-center rounded-md px-2 py-2 text-sm`}
                      >
                        {el.icon}
                        {el.label}
                      </button>
                    )}
                  </Menu.Item>
                ))}
              </div>

              <div className='px-1 py-1'>
                <Menu.Item>
                  {({ active }) => (
                    <button
                      onClick={() => deleteClick(task?._id || task?.task_id)}
                      className={`${
                        active ? "bg-blue-500 text-white" : "text-red-900"
                      } group flex w-full items-center rounded-md px-2 py-2 text-sm`}
                    >
                      <Trash2 className='tm-icon mr-2 text-red-400' aria-hidden='true' />
                      Delete
                    </button>
                  )}
                </Menu.Item>
              </div>
            </Menu.Items>
          </Transition>
        </Menu>
      </div>

      {/* Update Task Modal */}
      {openEdit && task?.task_id && (
        <div className="fixed inset-0 z-50 overflow-y-auto">
          <div className="flex min-h-full items-center justify-center p-4 text-center">
            <UpdateTask
              key={task.task_id}
              open={openEdit}
              setOpen={setOpenEdit}
              taskId={task.task_id}
            />
          </div>
        </div>
      )}

      <AddSubTask open={open} setOpen={setOpen} />
      <ConfirmatioDialog
        open={openDialog}
        setOpen={setOpenDialog}
        onClick={deleteHandler}
      />
    </>
  );
};

export default TaskDialog;