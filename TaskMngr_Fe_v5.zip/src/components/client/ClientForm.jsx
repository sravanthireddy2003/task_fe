import React, { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { useNavigate } from "react-router-dom";
import * as Icons from "../../icons";
import { useDispatch, useSelector } from "react-redux";
import {
  createClient,
  updateClient,
  fetchClients,
  attachDocument,
} from "../../redux/slices/clientSlice";
import { fetchUsers, selectUsers } from "../../redux/slices/userSlice";
import ModalWrapper from "../ModalWrapper";
import Textbox from "../Textbox";
import FormField from "../ui/FormField";
import { validateEmail, validatePhone } from "../../utils/validationUtils";

const indianStates = [
  "Andhra Pradesh",
  "Arunachal Pradesh",
  "Assam",
  "Bihar",
  "Chhattisgarh",
  "Goa",
  "Gujarat",
  "Haryana",
  "Himachal Pradesh",
  "Jharkhand",
  "Karnataka",
  "Kerala",
  "Madhya Pradesh",
  "Maharashtra",
  "Manipur",
  "Meghalaya",
  "Mizoram",
  "Nagaland",
  "Odisha",
  "Punjab",
  "Rajasthan",
  "Sikkim",
  "Tamil Nadu",
  "Telangana",
  "Tripura",
  "Uttar Pradesh",
  "Uttarakhand",
  "West Bengal",
  "Andaman and Nicobar Islands",
  "Chandigarh",
  "Dadra and Nagar Haveli",
  "Daman and Diu",
  "Lakshadweep",
  "Delhi",
  "Puducherry",
  "Ladakh",
  "Jammu & Kashmir",
];

const ClientForm = ({
  open = false,
  setOpen = null,
  client = null,
  onSuccess = null,
  isModal = false,
}) => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
    setValue,
  } = useForm();
  const [submitError, setSubmitError] = useState(null);
  const [submitSuccess, setSubmitSuccess] = useState(null);
  const [files, setFiles] = useState([]);
  const users = useSelector(selectUsers) || [];
  const isEditMode = !!client;

  useEffect(() => {
    dispatch(fetchUsers());
  }, [dispatch]);

  // Pre-fill form when client is provided (edit mode)
  useEffect(() => {
    if (client) {
      setValue("name", client.name || "");
      setValue("email", client.email || "");
      setValue("phone", client.phone || "");
      setValue("company", client.company || "");
      setValue("address", client.address || "");
      setValue("district", client.district || "");
      setValue("state", client.state || "");
      setValue("pincode", client.pincode || "");
      setValue("taxId", client.taxId || "");
      setValue("industry", client.industry || "");
      setValue("notes", client.notes || "");
      setValue("status", client.status || "Active");
      setValue("managerId", client.manager_public_id || client.managerId || "");
    } else {
      reset();
    }
  }, [client, setValue, reset]);

  const isManager = (u) => {
    if (!u) return false;
    const role = (u.role || u.designation || u.title || u.roleName || "")
      .toString()
      .toLowerCase();
    if (role.includes("manager")) return true;
    if (
      Array.isArray(u.roles) &&
      u.roles.some((r) =>
        (r || "").toString().toLowerCase().includes("manager"),
      )
    )
      return true;
    if (
      (u.roleId || u.role_id || u.roleName) &&
      ("" + (u.roleId || u.role_id || u.roleName))
        .toLowerCase()
        .includes("manager")
    )
      return true;
    return false;
  };

  const managers = Array.isArray(users) ? users.filter(isManager) : [];

  const formatError = (err) => {
    if (!err) return null;
    if (typeof err === "string") return err;
    if (err.message) return err.message;
    if (err.error) return err.error;
    if (err.data) {
      if (typeof err.data === "string") return err.data;
      if (err.data.message) return err.data.message;
      if (err.data.error) return err.data.error;
    }
    try {
      return JSON.stringify(err);
    } catch (e) {
      return String(err);
    }
  };

  const onSubmit = async (data) => {
    try {
      setSubmitError(null);
      setSubmitSuccess(null);

      let result;
      if (isEditMode) {
        // Update mode
        result = await dispatch(
          updateClient({
            clientId: client.id,
            clientData: data,
          }),
        );
      } else {
        // Create mode
        result = await dispatch(createClient(data));
      }

      if (
        isEditMode
          ? updateClient.fulfilled.match(result)
          : createClient.fulfilled.match(result)
      ) {
        const payload = result.payload;
        if (payload && (payload.success === false || payload.error)) {
          const errMsg = payload.error || payload.message || "Operation failed";
          setSubmitError(errMsg);
          return;
        }

        const updated = payload?.data || payload;
        const successMsg = `Client "${updated?.name || updated?.company || "Updated"}" ${isEditMode ? "updated" : "added"} successfully.`;
        setSubmitSuccess(successMsg);
        dispatch(fetchClients());

        // Handle document uploads for new clients only
        if (!isEditMode && files.length > 0) {
          try {
            const clientId = updated?.id || updated?._id || updated?.public_id;
            if (clientId) {
              for (const f of files) {
                const form = new FormData();
                form.append("file", f, f.name);
                form.append("file_name", f.name);
                try {
                  const userJson =
                    localStorage.getItem("userInfo") ||
                    localStorage.getItem("user");
                  if (userJson) {
                    const u = JSON.parse(userJson);
                    if (u && (u.id || u._id || u.public_id))
                      form.append("uploaded_by", u.id || u._id || u.public_id);
                  }
                } catch (e) {
                  // ignore
                }

                const tenantId = localStorage.getItem("tenantId") || "";
                if (tenantId) form.append("tenantId", tenantId);

                const attachResult = await dispatch(
                  attachDocument({ clientId, document: form }),
                );
                if (!attachDocument.fulfilled.match(attachResult)) {
                  const errMsg =
                    formatError(attachResult.payload) ||
                    attachResult.error?.message ||
                    "Failed to upload document";
                  setSubmitError(errMsg);
                  return;
                }
              }
            }
          } catch (err) {
            setSubmitError(err?.message || "Failed to attach documents");
            return;
          }
        }

        if (isModal) {
          setOpen?.(false);
          onSuccess?.();
        } else {
          navigate("/admin/clients", {
            state: { created: true, message: successMsg },
          });
        }
      } else {
        const err =
          formatError(result.payload) ||
          result.error?.message ||
          "Operation failed";
        setSubmitError(err);
      }
    } catch (error) {
      setSubmitError(error?.message || "Unexpected error. Please try again.");
    }
  };

  const handleClose = () => {
    if (isModal && setOpen) {
      setOpen(false);
    } else {
      navigate("/admin/clients");
    }
  };

  const formContent = (
    <form
      onSubmit={handleSubmit(onSubmit)}
      className="space-y-12 px-8 pb-8"
    >
      {/* Error Alert */}
      {submitError && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-3">
          <p className="text-sm text-red-700">{submitError}</p>
        </div>
      )}

      {/* Success Alert */}
      {submitSuccess && (
        <div className="bg-green-50 border border-green-200 rounded-lg p-3">
          <p className="text-sm text-green-700">{submitSuccess}</p>
        </div>
      )}

      {/* Basic Information */}
      <div className="space-y-5">
        <h4 className="text-2xl font-bold text-gray-900">
          Basic Information
        </h4>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Textbox
            label="Name"
            required
            placeholder="Enter client name"
            icon={<Icons.User className="text-gray-400" />}
            {...register("name", {
              required: "Name is required",
              minLength: { value: 2, message: "Name must be at least 2 characters" },
              maxLength: { value: 100, message: "Name must be less than 100 characters" }
            })}
            error={errors.name?.message}
          />

          <Textbox
            label="Email"
            required
            type="email"
            placeholder="Enter email address"
            icon={<Icons.Mail className="text-gray-400" />}
            {...register("email", {
              required: "Email is required",
              validate: (value) => validateEmail(value) || "Invalid email format",
            })}
            error={errors.email?.message}
          />

          <Textbox
            label="Phone"
            required
            placeholder="Enter 10-digit phone"
            maxLength="10"
            icon={<Icons.Phone className="text-gray-400" />}
            {...register("phone", {
              required: "Phone is required",
              validate: (value) => validatePhone(value) || "Valid 10 digit phone number required",
            })}
            onInput={(e) => {
              e.target.value = e.target.value.replace(/[^0-9]/g, "").slice(0, 10);
            }}
            error={errors.phone?.message}
          />

          <Textbox
            label="Company"
            placeholder="Enter company name"
            icon={<Icons.Briefcase className="text-gray-400" />}
            {...register("company", {
              minLength: { value: 2, message: "Company name must be at least 2 characters" },
              maxLength: { value: 100, message: "Company name must be less than 100 characters" }
            })}
            error={errors.company?.message}
          />
        </div>
      </div>

      {/* Address Information */}
      <div className="space-y-5">
        <h4 className="text-2xl font-bold text-gray-900">Address</h4>
        <div>
          <FormField label="Street Address">
            <textarea
              {...register("address")}
              className="w-full px-5 py-4 border-2 border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-base bg-white"
              placeholder="Enter street address"
              rows="4"
            />
          </FormField>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Textbox
              label="District"
              placeholder="Enter district"
              {...register("district", {
                pattern: {
                  value: /^[a-zA-Z\s]*$/,
                  message: "Only alphabets are allowed",
                }
              })}
              error={errors.district?.message}
            />
            <FormField label="State">
              <select
                {...register("state")}
                className="w-full px-5 py-4 border-2 border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-base bg-white"
              >
                <option value="">Select State</option>
                {indianStates.map((state) => (
                  <option key={state} value={state}>
                    {state}
                  </option>
                ))}
              </select>
            </FormField>
            <Textbox
              label="Pincode"
              placeholder="Enter pincode"
              maxLength="6"
              {...register("pincode", {
                pattern: { value: /^[0-9]{6}$/, message: "Valid 6 digit pincode required" },
              })}
              onInput={(e) => {
                e.target.value = e.target.value.replace(/[^0-9]/g, "").slice(0, 6);
              }}
              error={errors.pincode?.message}
            />
          </div>
        </div>
      </div>

      {/* Additional Details */}
      <div className="space-y-5">
        <h4 className="text-2xl font-bold text-gray-900">Details</h4>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Textbox
            label="GST/Tax ID"
            placeholder="Enter GST ID (e.g., 22AAAAA0000A1Z5)"
            maxLength="15"
            style={{ textTransform: "uppercase" }}
            {...register("taxId", {
              pattern: {
                value: /^[a-zA-Z0-9]{15}$/,
                message: "GST must be exactly 15 alphanumeric characters",
              }
            })}
            onInput={(e) => {
              e.target.value = e.target.value.toUpperCase();
            }}
            error={errors.taxId?.message}
          />

          <Textbox
            label="Industry"
            placeholder="Enter industry"
            {...register("industry", {
              minLength: { value: 2, message: "Industry must be at least 2 characters" },
              maxLength: { value: 50, message: "Industry must be less than 50 characters" },
              pattern: {
                value: /^[a-zA-Z\s]*$/,
                message: "Only alphabets are allowed",
              }
            })}
            error={errors.industry?.message}
          />
        </div>
        <FormField label="Notes">
          <textarea
            {...register("notes")}
            className="w-full px-5 py-4 border-2 border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-base bg-white"
            placeholder="Enter additional notes"
            rows="4"
          />
        </FormField>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <FormField label="Status">
            <select
              {...register("status")}
              className="w-full px-5 py-4 border-2 border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-base bg-white"
            >
              <option value="Active">Active</option>
              <option value="Inactive">Inactive</option>
              <option value="Lead">Lead</option>
            </select>
          </FormField>
          <FormField label="Manager">
            <select
              {...register("managerId")}
              className="w-full px-5 py-4 border-2 border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-base bg-white"
            >
              <option value="">-- Select Manager (optional) --</option>
              {managers.map((m) => (
                <option
                  key={m.public_id || m._id || m.id}
                  value={m.public_id || m._id || m.id}
                >
                  {m.name || m.firstName || m.email}
                </option>
              ))}
            </select>
          </FormField>
        </div>
      </div>

      {/* Documents (only for new clients) */}
      {!isEditMode && (
        <div>
          <label className="block text-sm font-semibold text-gray-700 mb-3">
            Attach Documents
          </label>
          <input
            type="file"
            multiple
            onChange={(e) => setFiles(Array.from(e.target.files || []))}
            className="w-full px-5 py-4 border-2 border-gray-300 rounded-xl text-base"
          />
          <p className="text-sm text-gray-600 mt-3 font-medium">PDF, DOCX, images</p>
        </div>
      )}

      {/* Action Buttons */}
      <div className="flex justify-end gap-4 pt-6 border-t-2 border-gray-200">
        <button
          type="button"
          onClick={handleClose}
          className="px-10 py-4 text-lg rounded-xl font-semibold text-gray-700 border-2 border-gray-300 hover:bg-gray-50 transition-colors"
        >
          Cancel
        </button>
        <button
          type="submit"
          className="px-10 py-4 text-lg rounded-xl font-semibold text-white bg-blue-600 hover:bg-blue-700 transition-colors"
        >
          {isEditMode ? "Update Client" : "Add Client"}
        </button>
      </div>
    </form>
  );

  const headerContent = (
    <div className="flex items-center justify-between">
      <h2 className="text-lg font-semibold text-gray-900">
        {isEditMode ? "Edit Client" : "Add New Client"}
      </h2>
      {isModal && (
        <button
          onClick={() => setOpen(false)}
          className="text-gray-400 hover:text-gray-600 transition-colors"
        >
          <Icons.X className="w-5 h-5" />
        </button>
      )}
    </div>
  );

  // If modal mode, return wrapped in ModalWrapper
  if (isModal) {
    return (
      <ModalWrapper open={open} setOpen={setOpen}>
        <div className="mb-8 px-8">{headerContent}</div>
        <div className="max-h-[calc(100vh-200px)] overflow-y-auto">
          {formContent}
        </div>
      </ModalWrapper>
    );
  }

  // If page mode, return as page
  return (
    <div className="p-6 bg-gray-50 min-h-screen">
      <div className="max-w-[90rem] mx-auto bg-white rounded-xl shadow border">
        <div className="p-6 border-b border-gray-200">{headerContent}</div>
        <div className="p-12">{formContent}</div>
      </div>
    </div>
  );
};

export default ClientForm;
