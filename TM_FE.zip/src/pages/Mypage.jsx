import React from 'react'

const Mypage = () => {
  return (
    <div>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Earum beatae quaerat, exercitationem error, dolores recusandae aperiam sapiente, vero et ullam quidem. Explicabo tenetur officiis iusto molestiae cupiditate illo tempora recusandae?</div>
  )
}

export default Mypage